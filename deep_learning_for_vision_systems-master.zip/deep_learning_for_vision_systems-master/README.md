# Deep Learning for Vision System

Deep Learning for Vision System book by Mohamed Elgendy


This is the official repository for the [Deep Learning for Vision Systems](https://www.amazon.com/gp/product/1617296198) book.
