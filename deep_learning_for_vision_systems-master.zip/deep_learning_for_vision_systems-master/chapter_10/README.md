### Please open the project notebook to view a list of instructions for training and testing embeddings for visual recognition
